<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

// This line protects the file from being accessed by a URL directly.
defined('MOODLE_INTERNAL') || die();

// This is used for performance, we don't need to know about these settings on every page in Moodle, only when
// we are looking at the admin settings pages.
if ($ADMIN->fulltree) {

    // Boost provides a nice setting page which splits settings onto separate tabs. We want to use it here.
    $settings = new theme_boost_admin_settingspage_tabs('themesettingedumy', get_string('configtitle', 'theme_edumy'));

    // CCN General settings
    $page = new admin_settingpage('theme_edumy_general', get_string('general_settings', 'theme_edumy'));

    // Blog style
    $setting = new admin_setting_configselect('theme_edumy/blogstyle',
        get_string('blogstyle', 'theme_edumy'),
        get_string('blogstyle_desc', 'theme_edumy'), null,
                array('1' => 'Blog style 1',
                      '2' => 'Blog style 2',
                      '3' => 'Blog style 3'
                    ));
    $page->add($setting);

    // Back to Top
    $setting = new admin_setting_configselect('theme_edumy/back_to_top',
        get_string('back_to_top', 'theme_edumy'),
        get_string('back_to_top_desc', 'theme_edumy'), null,
                array('0' => 'Visible',
                      '1' => 'Hidden'
                    ));
    $page->add($setting);


    // Favicon
    $name='theme_edumy/favicon';
    $title = get_string('favicon', 'theme_edumy');
    $description = get_string('favicon_desc', 'theme_edumy');
    $setting = new admin_setting_configstoredfile($name, $title, $description, 'favicon');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    $settings->add($page);

    // CCN Logo settings
    $page = new admin_settingpage('theme_edumy_logo', get_string('logo_settings', 'theme_edumy'));

    // Header logos
    $page->add(new admin_setting_heading('theme_edumy/header_logos', get_string('header_logos', 'theme_edumy'), NULL));

    // Logotype
    $setting = new admin_setting_configselect('theme_edumy/logotype',
        get_string('logotype', 'theme_edumy'),
        get_string('logotype_desc', 'theme_edumy'), null,
                array('0' => 'Visible',
                      '1' => 'Hidden'
                    ));
    $page->add($setting);

    // Logo image
    $setting = new admin_setting_configselect('theme_edumy/logo_image',
        get_string('logo_image', 'theme_edumy'),
        get_string('logo_image_desc', 'theme_edumy'), null,
                array('0' => 'Visible',
                      '1' => 'Hidden'
                    ));
    $page->add($setting);

    // Logo Image Width
    $setting = new admin_setting_configtext('theme_edumy/logo_image_width', get_string('logo_image_width','theme_edumy'), get_string('logo_image_width_desc', 'theme_edumy'), '', PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Logo Image Height
    $setting = new admin_setting_configtext('theme_edumy/logo_image_height', get_string('logo_image_height','theme_edumy'), get_string('logo_image_height_desc', 'theme_edumy'), '', PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Header logo 1
    $name='theme_edumy/headerlogo1';
    $title = get_string('headerlogo1', 'theme_edumy');
    $description = get_string('headerlogo1_desc', 'theme_edumy');
    $setting = new admin_setting_configstoredfile($name, $title, $description, 'headerlogo1');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Header logo 2
    $name='theme_edumy/headerlogo2';
    $title = get_string('headerlogo2', 'theme_edumy');
    $description = get_string('headerlogo2_desc', 'theme_edumy');
    $setting = new admin_setting_configstoredfile($name, $title, $description, 'headerlogo2');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Header logo 3
    $name='theme_edumy/headerlogo3';
    $title = get_string('headerlogo3', 'theme_edumy');
    $description = get_string('headerlogo3_desc', 'theme_edumy');
    $setting = new admin_setting_configstoredfile($name, $title, $description, 'headerlogo3');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Footer logos
    $page->add(new admin_setting_heading('theme_edumy/footer_logos', get_string('footer_logos', 'theme_edumy'), NULL));

    // Logotype Footer
    $setting = new admin_setting_configselect('theme_edumy/logotype_footer',
        get_string('logotype_footer', 'theme_edumy'),
        get_string('logotype_footer_desc', 'theme_edumy'), null,
                array('0' => 'Visible',
                      '1' => 'Hidden'
                    ));
    $page->add($setting);

    // Logo image Footer
    $setting = new admin_setting_configselect('theme_edumy/logo_image_footer',
        get_string('logo_image_footer', 'theme_edumy'),
        get_string('logo_image_footer_desc', 'theme_edumy'), null,
                array('0' => 'Visible',
                      '1' => 'Hidden'
                    ));
    $page->add($setting);

    // Logo Image Width footer
    $setting = new admin_setting_configtext('theme_edumy/logo_image_width_footer', get_string('logo_image_width_footer','theme_edumy'), get_string('logo_image_width_footer_desc', 'theme_edumy'), '', PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Logo Image Height footer
    $setting = new admin_setting_configtext('theme_edumy/logo_image_height_footer', get_string('logo_image_height_footer','theme_edumy'), get_string('logo_image_height_footer_desc', 'theme_edumy'), '', PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Footer logo 1
    $name='theme_edumy/footerlogo1';
    $title = get_string('footerlogo1', 'theme_edumy');
    $description = get_string('footerlogo1_desc', 'theme_edumy');
    $setting = new admin_setting_configstoredfile($name, $title, $description, 'footerlogo1');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    $settings->add($page);

    // CCN Header settings
    $page = new admin_settingpage('theme_edumy_header', get_string('header_settings', 'theme_edumy'));

    // Library list
    $setting = new admin_setting_configselect('theme_edumy/library_list',
        get_string('library_list', 'theme_edumy'),
        get_string('library_list_desc', 'theme_edumy'), null,
                array('0' => 'Hidden',
                      '1' => 'Visible'
                    ));
    $page->add($setting);

    // Search
    $setting = new admin_setting_configselect('theme_edumy/header_search',
        get_string('header_search', 'theme_edumy'),
        get_string('header_search_desc', 'theme_edumy'), null,
                array('0' => 'Show icon',
                      '1' => 'Show searchbar',
                      '2' => 'Hide'
                    ));
    $page->add($setting);

    // Login
    $setting = new admin_setting_configselect('theme_edumy/header_login',
        get_string('header_login', 'theme_edumy'),
        get_string('header_login_desc', 'theme_edumy'), null,
                array('0' => 'Login popup',
                      '1' => 'Login link',
                      '2' => 'Hide'
                    ));
    $page->add($setting);

    // Header type
    $setting = new admin_setting_configselect('theme_edumy/headertype',
        get_string('headertype', 'theme_edumy'),
        get_string('headertype_desc', 'theme_edumy'), null,
                array('1' => 'Header 1',
                      '2' => 'Header 2',
                      '3' => 'Header 3',
                      '4' => 'Header 4',
                      '5' => 'Header 5',
                      '6' => 'Header 6',
                      '7' => 'Header 7',
                      '8' => 'Header 8'
                    ));
    $page->add($setting);

    // Header type settings
    $setting = new admin_setting_configselect('theme_edumy/headertype_settings',
        get_string('headertype_settings', 'theme_edumy'),
        get_string('headertype_settings_desc', 'theme_edumy'), null,
                array('0' => 'Frontpage only',
                      '1' => 'All pages (beta)'
                    ));
    $page->add($setting);

    // Header email address
    $setting = new admin_setting_configtext('theme_edumy/email_address', get_string('email_address','theme_edumy'), get_string('email_address_desc', 'theme_edumy'), 'hello@edumy.com', PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Header phone
    $setting = new admin_setting_configtext('theme_edumy/phone', get_string('phone','theme_edumy'), get_string('phone_desc', 'theme_edumy'), '(56) 123 456 789', PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Call to Action Text
    $setting = new admin_setting_configtext('theme_edumy/cta_text', get_string('cta_text','theme_edumy'), get_string('cta_text_desc', 'theme_edumy'), 'Become an Instructor', PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Call to Action Link
    $setting = new admin_setting_configtext('theme_edumy/cta_link', get_string('cta_link','theme_edumy'), get_string('cta_link_desc', 'theme_edumy'), '#', PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    $settings->add($page);

    // CCN Breadcrumb settings
    $page = new admin_settingpage('breadcrumb_settings', get_string('breadcrumb_settings', 'theme_edumy'));
    // Breadcrumb settings
    $page->add(new admin_setting_heading('theme_edumy/breadcrumb_settings', get_string('breadcrumb_settings', 'theme_edumy'), NULL));

    // Breadcrumb background
    $name='theme_edumy/heading_bg';
    $title = get_string('heading_bg', 'theme_edumy');
    $description = get_string('heading_bg_desc', 'theme_edumy');
    $setting = new admin_setting_configstoredfile($name, $title, $description, 'heading_bg');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Breadcrumb style
    $setting = new admin_setting_configselect('theme_edumy/breadcrumb_style',
        get_string('breadcrumb_style', 'theme_edumy'),
        get_string('breadcrumb_style_desc', 'theme_edumy'), 0,
                array('0' => 'Default (large)',
                      '1' => 'Medium',
                      '2' => 'Small',
                      '3' => 'Extra small',
                      '4' => 'Hidden'
                    ));
    $page->add($setting);

    $settings->add($page);

    // CCN Preloader settings
    $page = new admin_settingpage('preloader_settings', get_string('preloader_settings', 'theme_edumy'));
    // Preloader settings
    $page->add(new admin_setting_heading('theme_edumy/preloader_settings', get_string('preloader_settings', 'theme_edumy'), NULL));

    // Preloader image
    $name='theme_edumy/preloader_image';
    $title = get_string('preloader_image', 'theme_edumy');
    $description = get_string('preloader_image_desc', 'theme_edumy');
    $setting = new admin_setting_configstoredfile($name, $title, $description, 'preloader_image');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Preloader duration
    $setting = new admin_setting_configselect('theme_edumy/preloader_duration',
        get_string('preloader_duration', 'theme_edumy'),
        get_string('preloader_duration_desc', 'theme_edumy'), 0,
                array('0' => 'Wait for page to fully load (highly recommended)',
                      '1' => 'Wait for core elements to load',
                      '2' => 'Wait for page to fully load, but no longer than 5 seconds',
                      '3' => 'Wait for page to fully load, but no longer than 4 seconds',
                      '4' => 'Wait for page to fully load, but no longer than 3 seconds',
                      '5' => 'Wait for page to fully load, but no longer than 2 seconds',
                      '6' => 'Disable preloader (not recommended)'
                    ));
    $page->add($setting);

    $settings->add($page);

    // CCN Footer settings
    $page = new admin_settingpage('theme_edumy_footer', get_string('footer_settings', 'theme_edumy'));
    // Footer settings
    $page->add(new admin_setting_heading('theme_edumy/footer_settings', get_string('footer_settings', 'theme_edumy'), NULL));


    // Footer copyright
    $setting = new admin_setting_configtext('theme_edumy/cocoon_copyright', get_string('cocoon_copyright','theme_edumy'), get_string('cocoon_copyright_desc', 'theme_edumy'), 'Copyright © 2020 Edumy Moodle Theme by Cocoon. All Rights Reserved.', PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Footer style
    $setting = new admin_setting_configselect('theme_edumy/footertype',
        get_string('footertype', 'theme_edumy'),
        get_string('footertype_desc', 'theme_edumy'), null,
                array('1' => 'Footer 1',
                      '2' => 'Footer 2',
                      '3' => 'Footer 3',
                      '4' => 'Footer 4'
                    ));
    $page->add($setting);
    // Footer column 1
    $page->add(new admin_setting_heading('theme_edumy/footer_col_1', get_string('footer_col_1', 'theme_edumy'), NULL));
    // Footer column title
    $setting = new admin_setting_configtext('theme_edumy/footer_col_1_title', get_string('footer_col_title','theme_edumy'), get_string('footer_col_title_desc', 'theme_edumy'), 'Contact', PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Footer column body
    $setting = new admin_setting_configtextarea('theme_edumy/footer_col_1_body', get_string('footer_col_body','theme_edumy'), get_string('footer_col_body_desc', 'theme_edumy'), 'Body text for the first column.', PARAM_RAW);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Footer column 2
    $page->add(new admin_setting_heading('theme_edumy/footer_col_2', get_string('footer_col_2', 'theme_edumy'), NULL));
    // Footer column title
    $setting = new admin_setting_configtext('theme_edumy/footer_col_2_title', get_string('footer_col_title','theme_edumy'), get_string('footer_col_title_desc', 'theme_edumy'), 'Company', PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Footer column body
    $setting = new admin_setting_configtextarea('theme_edumy/footer_col_2_body', get_string('footer_col_body','theme_edumy'), get_string('footer_col_body_desc', 'theme_edumy'), 'Body text for the second column.', PARAM_RAW);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Footer column 3
    $page->add(new admin_setting_heading('theme_edumy/footer_col_3', get_string('footer_col_3', 'theme_edumy'), NULL));
    // Footer column title
    $setting = new admin_setting_configtext('theme_edumy/footer_col_3_title', get_string('footer_col_title','theme_edumy'), get_string('footer_col_title_desc', 'theme_edumy'), 'Programs', PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Footer column body
    $setting = new admin_setting_configtextarea('theme_edumy/footer_col_3_body', get_string('footer_col_body','theme_edumy'), get_string('footer_col_body_desc', 'theme_edumy'), 'Body text for the third column.', PARAM_RAW);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Footer column 4
    $page->add(new admin_setting_heading('theme_edumy/footer_col_4', get_string('footer_col_4', 'theme_edumy'), NULL));
    // Footer column title
    $setting = new admin_setting_configtext('theme_edumy/footer_col_4_title', get_string('footer_col_title','theme_edumy'), get_string('footer_col_title_desc', 'theme_edumy'), 'Support', PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Footer column body
    $setting = new admin_setting_configtextarea('theme_edumy/footer_col_4_body', get_string('footer_col_body','theme_edumy'), get_string('footer_col_body_desc', 'theme_edumy'), 'Body text for the fourth column.', PARAM_RAW);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Footer column 5
    $page->add(new admin_setting_heading('theme_edumy/footer_col_5', get_string('footer_col_5', 'theme_edumy'), NULL));
    // Footer column title
    $setting = new admin_setting_configtext('theme_edumy/footer_col_5_title', get_string('footer_col_title','theme_edumy'), get_string('footer_col_title_desc', 'theme_edumy'), 'Mobile', PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Footer column body
    $setting = new admin_setting_configtextarea('theme_edumy/footer_col_5_body', get_string('footer_col_body','theme_edumy'), get_string('footer_col_body_desc', 'theme_edumy'), 'Body text for the fifth column.', PARAM_RAW);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Footer menu
    $page->add(new admin_setting_heading('theme_edumy/footer_menu_heading', get_string('footer_menu', 'theme_edumy'), NULL));
    // Footer menu
    $setting = new admin_setting_configtextarea('theme_edumy/footer_menu', get_string('footer_menu','theme_edumy'), get_string('footer_menu_desc', 'theme_edumy'), 'Body text for the footer menu.', PARAM_RAW);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    $settings->add($page);

    // CCN Course settings
    $page = new admin_settingpage('theme_edumy_course_settings', get_string('course_settings', 'theme_edumy'));

    // Category settings
    $page->add(new admin_setting_heading('theme_edumy/coursecat_settings', get_string('coursecat_settings', 'theme_edumy'), NULL));

    // Modified on Course categories
    $setting = new admin_setting_configselect('theme_edumy/coursecat_modified',
        get_string('coursecat_modified', 'theme_edumy'),
        get_string('coursecat_modified_desc', 'theme_edumy'), 0,
                array('0' => 'Visible',
                      '1' => 'Hidden',
                    ));
    $page->add($setting);

    // Course settings
    $page->add(new admin_setting_heading('theme_edumy/course_settings', get_string('course_settings_long', 'theme_edumy'), NULL));

    // Course list style
    $setting = new admin_setting_configselect('theme_edumy/courseliststyle',
        get_string('courseliststyle', 'theme_edumy'),
        get_string('courseliststyle_desc', 'theme_edumy'), null,
                array('1' => 'Grid',
                      '2' => 'List'
                    ));
    $page->add($setting);


     // Enroled access to course content only
    $setting = new admin_setting_configselect('theme_edumy/course_content_enroled_only',
        get_string('course_content_enroled_only', 'theme_edumy'),
        get_string('course_content_enroled_only_desc', 'theme_edumy'), 0,
                array('0' => 'Display course content to anyone with viewing access to the course',
                      '1' => 'Display course content only to enroled users and administrators',
                    ));
    $page->add($setting);

    // Topics format settings
    $page->add(new admin_setting_heading('theme_edumy/course_settings_topics_format', get_string('course_settings_topics_format', 'theme_edumy'), NULL));

    // Collapsible settings
    $setting = new admin_setting_configselect('theme_edumy/topics_format_collapsible',
        get_string('topics_format_collapsible', 'theme_edumy'),
        get_string('topics_format_collapsible_desc', 'theme_edumy'), null,
                array('0' => 'All collapsed by default',
                      '1' => 'All collapsed, first expanded',
                      '2' => 'All expanded by default',
                      '3' => 'All expanded and not collapsible',
                    ));
    $page->add($setting);


    $settings->add($page);

    // CCN Social settings
    $page = new admin_settingpage('theme_edumy_social_settings', get_string('social_settings', 'theme_edumy'));

    // New Window
    $setting = new admin_setting_configselect('theme_edumy/social_target',
        get_string('social_target', 'theme_edumy'),
        get_string('social_target_desc', 'theme_edumy'), null,
                array('0' => 'Open URLs in the same page',
                      '1' => 'Open URLs in a new window'
                    ));
    $page->add($setting);

    // Facebook URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_facebook_url', get_string('cocoon_facebook_url','theme_edumy'), get_string('cocoon_facebook_url_desc', 'theme_edumy'), '#', PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Twitter URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_twitter_url', get_string('cocoon_twitter_url','theme_edumy'), get_string('cocoon_twitter_url_desc', 'theme_edumy'), '#', PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Instagram URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_instagram_url', get_string('cocoon_instagram_url','theme_edumy'), get_string('cocoon_instagram_url_desc', 'theme_edumy'), '#', PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Pinterest URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_pinterest_url', get_string('cocoon_pinterest_url','theme_edumy'), get_string('cocoon_pinterest_url_desc', 'theme_edumy'), '#', PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Dribbble URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_dribbble_url', get_string('cocoon_dribbble_url','theme_edumy'), get_string('cocoon_dribbble_url_desc', 'theme_edumy'), '#', PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Google URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_google_url', get_string('cocoon_google_url','theme_edumy'), get_string('cocoon_google_url_desc', 'theme_edumy'), '#', PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // YouTube URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_youtube_url', get_string('cocoon_youtube_url','theme_edumy'), get_string('cocoon_youtube_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // VK URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_vk_url', get_string('cocoon_vk_url','theme_edumy'), get_string('cocoon_vk_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // 500px URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_500px_url', get_string('cocoon_500px_url','theme_edumy'), get_string('cocoon_500px_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Behance URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_behance_url', get_string('cocoon_behance_url','theme_edumy'), get_string('cocoon_behance_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Digg URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_digg_url', get_string('cocoon_digg_url','theme_edumy'), get_string('cocoon_digg_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Flickr URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_flickr_url', get_string('cocoon_flickr_url','theme_edumy'), get_string('cocoon_flickr_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Foursquare URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_foursquare_url', get_string('cocoon_foursquare_url','theme_edumy'), get_string('cocoon_foursquare_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // LinkedIn URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_linkedin_url', get_string('cocoon_linkedin_url','theme_edumy'), get_string('cocoon_linkedin_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Medium URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_medium_url', get_string('cocoon_medium_url','theme_edumy'), get_string('cocoon_medium_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Meetup URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_meetup_url', get_string('cocoon_meetup_url','theme_edumy'), get_string('cocoon_meetup_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Snapchat URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_snapchat_url', get_string('cocoon_snapchat_url','theme_edumy'), get_string('cocoon_snapchat_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Tumblr URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_tumblr_url', get_string('cocoon_tumblr_url','theme_edumy'), get_string('cocoon_tumblr_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Vimeo URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_vimeo_url', get_string('cocoon_vimeo_url','theme_edumy'), get_string('cocoon_vimeo_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // WeChat URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_wechat_url', get_string('cocoon_wechat_url','theme_edumy'), get_string('cocoon_wechat_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // WhatsApp URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_whatsapp_url', get_string('cocoon_whatsapp_url','theme_edumy'), get_string('cocoon_whatsapp_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // WordPress URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_wordpress_url', get_string('cocoon_wordpress_url','theme_edumy'), get_string('cocoon_wordpress_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Weibo URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_weibo_url', get_string('cocoon_weibo_url','theme_edumy'), get_string('cocoon_weibo_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Telegram URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_telegram_url', get_string('cocoon_telegram_url','theme_edumy'), get_string('cocoon_telegram_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Moodle URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_moodle_url', get_string('cocoon_moodle_url','theme_edumy'), get_string('cocoon_moodle_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Amazon URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_amazon_url', get_string('cocoon_amazon_url','theme_edumy'), get_string('cocoon_amazon_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Slideshare URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_slideshare_url', get_string('cocoon_slideshare_url','theme_edumy'), get_string('cocoon_slideshare_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // SoundCloud URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_soundcloud_url', get_string('cocoon_soundcloud_url','theme_edumy'), get_string('cocoon_soundcloud_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // LeanPub URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_leanpub_url', get_string('cocoon_leanpub_url','theme_edumy'), get_string('cocoon_leanpub_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Xing URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_xing_url', get_string('cocoon_xing_url','theme_edumy'), get_string('cocoon_xing_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Bitcoin URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_bitcoin_url', get_string('cocoon_bitcoin_url','theme_edumy'), get_string('cocoon_bitcoin_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Twitch URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_twitch_url', get_string('cocoon_twitch_url','theme_edumy'), get_string('cocoon_twitch_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Github URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_github_url', get_string('cocoon_github_url','theme_edumy'), get_string('cocoon_github_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Gitlab URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_gitlab_url', get_string('cocoon_gitlab_url','theme_edumy'), get_string('cocoon_gitlab_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Forumbee URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_forumbee_url', get_string('cocoon_forumbee_url','theme_edumy'), get_string('cocoon_forumbee_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Trello URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_trello_url', get_string('cocoon_trello_url','theme_edumy'), get_string('cocoon_trello_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Weixin URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_weixin_url', get_string('cocoon_weixin_url','theme_edumy'), get_string('cocoon_weixin_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Slack URL
    $setting = new admin_setting_configtext('theme_edumy/cocoon_slack_url', get_string('cocoon_slack_url','theme_edumy'), get_string('cocoon_slack_url_desc', 'theme_edumy'), null, PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);


    $settings->add($page);

    // CCN Color settings
    $page = new admin_settingpage('theme_edumy_color', get_string('color_settings', 'theme_edumy'));

    // Title: Gradients
    $page->add(new admin_setting_heading('theme_edumy/color_settings_gradient', get_string('color_settings_gradient', 'theme_edumy'), NULL));

    // Gradient Start
    $setting = new admin_setting_configcolourpicker('theme_edumy/color_gradient_start', get_string('color_gradient_start','theme_edumy'), get_string('color_gradient_start_desc', 'theme_edumy'), '#ff1053');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Gradient End
    $setting = new admin_setting_configcolourpicker('theme_edumy/color_gradient_end', get_string('color_gradient_end','theme_edumy'), get_string('color_gradient_end_desc', 'theme_edumy'), '#3452ff');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Title: Main colors
    $page->add(new admin_setting_heading('theme_edumy/color_settings_main', get_string('color_settings_main', 'theme_edumy'), NULL));

    // Primary Color
    $setting = new admin_setting_configcolourpicker('theme_edumy/color_primary', get_string('color_primary','theme_edumy'), get_string('color_primary_desc', 'theme_edumy'), '#2441e7');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Secondary Color
    $setting = new admin_setting_configcolourpicker('theme_edumy/color_secondary', get_string('color_secondary','theme_edumy'), get_string('color_secondary_desc', 'theme_edumy'), '#ff1053');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Tertiary Color
    $setting = new admin_setting_configcolourpicker('theme_edumy/color_tertiary', get_string('color_tertiary','theme_edumy'), get_string('color_tertiary_desc', 'theme_edumy'), '#6c757d');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Accent Color
    $setting = new admin_setting_configcolourpicker('theme_edumy/color_accent', get_string('color_accent','theme_edumy'), get_string('color_accent_desc', 'theme_edumy'), '#e35a9a');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Accent Color 2
    $setting = new admin_setting_configcolourpicker('theme_edumy/color_accent_2', get_string('color_accent_2','theme_edumy'), get_string('color_accent_2_desc', 'theme_edumy'), '#c75533');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Accent Color 3
    $setting = new admin_setting_configcolourpicker('theme_edumy/color_accent_3', get_string('color_accent_3','theme_edumy'), get_string('color_accent_3_desc', 'theme_edumy'), '#192675');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Parallax Color
    $setting = new admin_setting_configcolourpicker('theme_edumy/color_parallax', get_string('color_parallax','theme_edumy'), get_string('color_parallax_desc', 'theme_edumy'), '#2441e7');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Title: Header Style 2
    $page->add(new admin_setting_heading('theme_edumy/color_settings_header_style_2', get_string('color_settings_header_style_2', 'theme_edumy'), NULL));

    // Header Style 2: Header Top
    $setting = new admin_setting_configcolourpicker('theme_edumy/color_header_style_2_top', get_string('color_header_color_top','theme_edumy'), get_string('color_header_color_top_desc', 'theme_edumy'), '#000');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Header Style 2: Header Bottom
    $setting = new admin_setting_configcolourpicker('theme_edumy/color_header_style_2_bottom', get_string('color_header_color_bottom','theme_edumy'), get_string('color_header_color_bottom_desc', 'theme_edumy'), '#141414');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Title: Header Style 4
    $page->add(new admin_setting_heading('theme_edumy/color_settings_header_style_4', get_string('color_settings_header_style_4', 'theme_edumy'), NULL));

    // Header Style 4: Header Top
    $setting = new admin_setting_configcolourpicker('theme_edumy/color_header_style_4_top', get_string('color_header_color_top','theme_edumy'), get_string('color_header_color_top_desc', 'theme_edumy'), '#3452ff');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Title: Header Style 5
    $page->add(new admin_setting_heading('theme_edumy/color_settings_header_style_5', get_string('color_settings_header_style_5', 'theme_edumy'), NULL));

    // Header Style 5
    $setting = new admin_setting_configcolourpicker('theme_edumy/color_header_style_5', get_string('color_header_color','theme_edumy'), get_string('color_header_color_desc', 'theme_edumy'), '#ffffff');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Title: Header Style 6
    $page->add(new admin_setting_heading('theme_edumy/color_settings_header_style_6', get_string('color_settings_header_style_6', 'theme_edumy'), NULL));

    // Header Style 6: Header Top
    $setting = new admin_setting_configcolourpicker('theme_edumy/color_header_style_6_top', get_string('color_header_color_top','theme_edumy'), get_string('color_header_color_top_desc', 'theme_edumy'), '#3452ff');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);


    // Title: Footer Style 1
    $page->add(new admin_setting_heading('theme_edumy/color_settings_footer_style_1', get_string('color_settings_footer_style_1', 'theme_edumy'), NULL));

    // Footer Style 1: Footer Top
    $setting = new admin_setting_configcolourpicker('theme_edumy/color_footer_style_1_top', get_string('color_footer_color_top','theme_edumy'), get_string('color_footer_color_top_desc', 'theme_edumy'), '#151515');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Footer Style 1: Footer Bottom
    $setting = new admin_setting_configcolourpicker('theme_edumy/color_footer_style_1_bottom', get_string('color_footer_color_bottom','theme_edumy'), get_string('color_footer_color_bottom_desc', 'theme_edumy'), '#0a0a0a');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Title: Footer Style 2
    $page->add(new admin_setting_heading('theme_edumy/color_settings_footer_style_2', get_string('color_settings_footer_style_2', 'theme_edumy'), NULL));

    // Footer Style 2: Footer Top
    $setting = new admin_setting_configcolourpicker('theme_edumy/color_footer_style_2_top', get_string('color_footer_color_top','theme_edumy'), get_string('color_footer_color_top_desc', 'theme_edumy'), '#f9fafc');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Footer Style 2: Footer Bottom
    $setting = new admin_setting_configcolourpicker('theme_edumy/color_footer_style_2_bottom', get_string('color_footer_color_bottom','theme_edumy'), get_string('color_footer_color_bottom_desc', 'theme_edumy'), '#ebeef4');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Title: Footer Style 3
    $page->add(new admin_setting_heading('theme_edumy/color_settings_footer_style_3', get_string('color_settings_footer_style_3', 'theme_edumy'), NULL));

    // Footer Style 3: Footer Top
    $setting = new admin_setting_configcolourpicker('theme_edumy/color_footer_style_3_top', get_string('color_footer_color_top','theme_edumy'), get_string('color_footer_color_top_desc', 'theme_edumy'), '#f9fafc');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Footer Style 3: Footer Middle
    $setting = new admin_setting_configcolourpicker('theme_edumy/color_footer_style_3_middle', get_string('color_footer_color_middle','theme_edumy'), get_string('color_footer_color_middle_desc', 'theme_edumy'), '#ffffff');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Footer Style 3: Footer Bottom
    $setting = new admin_setting_configcolourpicker('theme_edumy/color_footer_style_3_bottom', get_string('color_footer_color_bottom','theme_edumy'), get_string('color_footer_color_bottom_desc', 'theme_edumy'), '#fafafa');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    $settings->add($page);

    // // CCN Dashboard settings
    // $page = new admin_settingpage('theme_edumy_dashboard', get_string('dashboard_settings', 'theme_edumy'));
    //
    // // Sticky header
    // $setting = new admin_setting_configselect('theme_edumy/dashboard_sticky_header',
    //     get_string('dashboard_sticky_header', 'theme_edumy'),
    //     get_string('dashboard_sticky_header_desc', 'theme_edumy'), null,
    //             array('0' => 'Stick to top',
    //                   '1' => 'Scroll with page'
    //                 ));
    // $page->add($setting);
    //
    // $settings->add($page);

    // CCN Advanced settings
    $page = new admin_settingpage('theme_edumy_advanced', get_string('advanced_settings', 'theme_edumy'));
    // Google Maps API Key
    $setting = new admin_setting_configtext('theme_edumy/gmaps_key', get_string('gmaps_key','theme_edumy'), get_string('gmaps_key_desc', 'theme_edumy'), '', PARAM_NOTAGS, 50);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Primary Font
    $setting = new admin_setting_configselect('theme_edumy/primary_font',
        get_string('primary_font', 'theme_edumy'),
        get_string('primary_font_desc', 'theme_edumy'), null,
                array('0' => 'Nunito',
                      '1' => 'Dosis',
                      '2' => 'Lato',
                      '3' => 'Maven Pro',
                      '4' => 'Montserrat',
                      '5' => 'Open Sans',
                      '6' => 'Playfair Display',
                      '7' => 'Poppins',
                      '8' => 'Raleway',
                      '9' => 'Roboto',
                    ));
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Secondary Font
    $setting = new admin_setting_configselect('theme_edumy/secondary_font',
        get_string('secondary_font', 'theme_edumy'),
        get_string('secondary_font_desc', 'theme_edumy'), 5,
                array('0' => 'Nunito',
                      '1' => 'Dosis',
                      '2' => 'Lato',
                      '3' => 'Maven Pro',
                      '4' => 'Montserrat',
                      '5' => 'Open Sans',
                      '6' => 'Playfair Display',
                      '7' => 'Poppins',
                      '8' => 'Raleway',
                      '9' => 'Roboto',
                    ));
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);


    // Custom CSS
    $setting = new admin_setting_configtextarea('theme_edumy/custom_css', get_string('custom_css','theme_edumy'), get_string('custom_css_desc', 'theme_edumy'), '', PARAM_RAW);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Custom CSS Dashboard
    $setting = new admin_setting_configtextarea('theme_edumy/custom_css_dashboard', get_string('custom_css_dashboard','theme_edumy'), get_string('custom_css_dashboard_desc', 'theme_edumy'), '', PARAM_RAW);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Custom JavaScript
    $setting = new admin_setting_configtextarea('theme_edumy/custom_js', get_string('custom_js','theme_edumy'), get_string('custom_js_desc', 'theme_edumy'), '', PARAM_RAW);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Custom JavaScript Dashboard
    $setting = new admin_setting_configtextarea('theme_edumy/custom_js_dashboard', get_string('custom_js_dashboard','theme_edumy'), get_string('custom_js_dashboard_desc', 'theme_edumy'), '', PARAM_RAW);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Blog Post Author
    $setting = new admin_setting_configselect('theme_edumy/blog_post_author',
        get_string('blog_post_author', 'theme_edumy'),
        get_string('blog_post_author_desc', 'theme_edumy'), null,
                array('0' => 'Visible',
                      '1' => 'Hidden'
                    ));
    $page->add($setting);

    $settings->add($page);

}
