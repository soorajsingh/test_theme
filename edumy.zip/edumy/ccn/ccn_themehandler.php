<?php
/*
@ccnRef: @theme_edumy/layout
*/

defined('MOODLE_INTERNAL') || die();
global $USER, $CFG, $SESSION, $OUTPUT, $COURSE, $DB;
require_once($CFG->libdir . '/behat/lib.php');
include($CFG->dirroot . '/theme/edumy/ccn/ccn_loginform.php');
// include($CFG->dirroot . '/theme/edumy/ccn/ccn_registrationform.php');
include($CFG->dirroot . '/theme/edumy/ccn/ccn_globalsearch.php');
include($CFG->dirroot . '/theme/edumy/ccn/ccn_globalsearch_navbar.php');
include($CFG->dirroot . '/theme/edumy/ccn/ccn_librarylist.php');
// include($CFG->dirroot . '/theme/edumy/ccn/ccn_activitynav.php');

if (is_siteadmin()) {$user_status = 'role-supreme';} else {$user_status = 'role-standard';}
if(!empty($OUTPUT->get_theme_image_headerlogo1())){
  $headerlogo1 = $OUTPUT->get_theme_image_headerlogo1(null, 100);
} else {
  $headerlogo1 = $CFG->wwwroot . '/theme/edumy/images/header-logo.png';
}
if(!empty($OUTPUT->get_theme_image_headerlogo2())){
  $headerlogo2 = $OUTPUT->get_theme_image_headerlogo2(null, 100);
} else {
  $headerlogo2 = $CFG->wwwroot . '/theme/edumy/images/header-logo2.png';
}
if(!empty($OUTPUT->get_theme_image_headerlogo3())){
  $headerlogo3 = $OUTPUT->get_theme_image_headerlogo3(null, 100);
} else {
  $headerlogo3 = $CFG->wwwroot . '/theme/edumy/images/header-logo4.png';
}
if(!empty($OUTPUT->get_theme_image_footerlogo1())){
  $footerlogo1 = $OUTPUT->get_theme_image_footerlogo1(null, 100);
} else {
  $footerlogo1 = $CFG->wwwroot . '/theme/edumy/images/header-logo.png';
}
if(!empty($OUTPUT->get_theme_image_heading_bg())){
  $heading_bg = $OUTPUT->get_theme_image_heading_bg(null, 100);
} else {
  $heading_bg = $CFG->wwwroot . '/theme/edumy/images/background/inner-pagebg.jpg';
}
if(!empty($OUTPUT->get_theme_image_favicon())){
  $favicon = $OUTPUT->get_theme_image_favicon(null, 100);
} else {
  $favicon = $CFG->wwwroot . '/theme/edumy/pix/favicon.ico';
}
$headertype = get_config('theme_edumy', 'headertype');
$headertype_settings = get_config('theme_edumy', 'headertype_settings');
$header_search = get_config('theme_edumy', 'header_search');
$header_login = get_config('theme_edumy', 'header_login');
$footertype = get_config('theme_edumy', 'footertype');
$breadcrumb_style = get_config('theme_edumy', 'breadcrumb_style');
$preloader_duration = get_config('theme_edumy', 'preloader_duration');
$blogstyle = get_config('theme_edumy', 'blogstyle');
$courseliststyle = get_config('theme_edumy', 'courseliststyle');
$back_to_top = get_config('theme_edumy', 'back_to_top');
$dashboard_sticky_header = get_config('theme_edumy', 'dashboard_sticky_header');
$logo_image_width = preg_replace("/[^0-9]/", "", get_config('theme_edumy', 'logo_image_width'));
$logo_image_height = preg_replace("/[^0-9]/", "", get_config('theme_edumy', 'logo_image_height'));
$logo_image_width_footer = preg_replace("/[^0-9]/", "", get_config('theme_edumy', 'logo_image_width_footer'));
$logo_image_height_footer = preg_replace("/[^0-9]/", "", get_config('theme_edumy', 'logo_image_height_footer'));
$logo_styles = '';
if ($logo_image_width) {
  $logo_styles .= 'width:'.$logo_image_width.'px;max-width:none!important;';
}
if ($logo_image_height) {
  $logo_styles .= 'height:'.$logo_image_height.'px;max-height:none!important;';
}
$logo_styles_footer = '';
if ($logo_image_width_footer) {
  $logo_styles_footer .= 'width:'.$logo_image_width_footer.'px;max-width:none!important;';
}
if ($logo_image_height_footer) {
  $logo_styles_footer .= 'height:'.$logo_image_height_footer.'px;max-height:none!important;';
}
$social_target = get_config('theme_edumy', 'social_target');
if($social_target == 1) {
  $social_target_href = 'target="_blank"';
} else {
  $social_target_href = 'target="_self"';
}
if ($PAGE->pagetype == 'site-index') {
  $ccn_frontcheck = 'ccn-is-front';
} else {
  $ccn_frontcheck = 'ccn-not-front';
}
if(get_config('theme_edumy', 'headertype_settings') == 1) {
  $headertype_settings_class = 'ccn_header_applies-all';
} else {
  $headertype_settings_class = 'ccn_header_applies-front';
}
// if ($PAGE->bodyid == 'page-grade-report-overview-index') {
//   $PAGE->set_pagelayout('admin');
// }
$extraclasses = array('ccn_header_style_' . $headertype, 'ccn_footer_style_' . $footertype, 'ccn_blog_style_' . $blogstyle, 'ccn_course_list_style_' . $courseliststyle, $user_status, $ccn_frontcheck, $headertype_settings_class);
$bodyclasses = implode(" ",$extraclasses);
$bodyattributes = $OUTPUT->body_attributes($bodyclasses);
$pageheading = $PAGE->heading;
$blockshtml = $OUTPUT->blocks('side-pre');
$leftblocks = $OUTPUT->blocks('left');
$hasblocks = strpos($blockshtml, 'data-block=') !== false;
$hasleftblocks = strpos($leftblocks, 'data-block=') !== false;
$regionmainsettingsmenu = $OUTPUT->region_main_settings_menu();
$hassideblocks = ($hasblocks || $hasleftblocks);
$blocks_user_notifications = $OUTPUT->blocks('user-notif');
$blocks_user_messages = $OUTPUT->blocks('user-messages');
$blocks_fullwidth_top = $OUTPUT->blocks('fullwidth-top');
$blocks_fullwidth_bottom = $OUTPUT->blocks('fullwidth-bottom');
$blocks_above_content = $OUTPUT->blocks('above-content');
$blocks_below_content = $OUTPUT->blocks('below-content');
$loginblocks = $OUTPUT->blocks('login');
$searchblocks = $OUTPUT->blocks('search');
$cocoon_facebook_url = get_config('theme_edumy', 'cocoon_facebook_url');
$cocoon_copyright = get_config('theme_edumy', 'cocoon_copyright');
$courseid = $PAGE->course->id;
$coursefullname = $PAGE->course->fullname;
$courseshortname = $PAGE->course->shortname;
if (!empty($PAGE->category->name)){$coursecategory = $PAGE->category->name;}else{$coursecategory = '';}
$coursesummary = $PAGE->course->summary;
$courseformat = $PAGE->course->format;
$coursecreated = userdate($PAGE->course->timecreated, get_string('strftimedatefullshort', 'langconfig'), 0);
$coursemodified = userdate($PAGE->course->timemodified, get_string('strftimedatefullshort', 'langconfig'), 0);
$coursestartdate = userdate($PAGE->course->startdate, get_string('strftimedatefullshort', 'langconfig'), 0);
$courseenddate = userdate($PAGE->course->enddate, get_string('strftimedatefullshort', 'langconfig'), 0);
$context = context_course::instance($courseid);
if($context){
  $is_enrolled = is_enrolled($context, $USER, '', true);
}
$course_content_enroled_only = get_config('theme_edumy', 'course_content_enroled_only');
if($course_content_enroled_only == 1 && ($is_enrolled == 1 || is_siteadmin())){
  $display_course_content = 1;
} elseif($course_content_enroled_only == 1 && $is_enrolled !== 1){
  $display_course_content = 0;
} elseif($course_content_enroled_only == 0){
  $display_course_content = 1;
} else {
  $display_course_content = 1;
}
$numberofusers = count_enrolled_users($context);
if (function_exists('isguestuser') && isguestuser() == 1) {
  $isloggedin = 'FALSE';
} elseif (isloggedin()) {
  $isloggedin = 'TRUE';
  $messages_link = $CFG->wwwroot . '/message/index.php';
  $profile_link = $CFG->wwwroot . '/user/profile.php?id=' . $USER->id;
  $grades_link = $CFG->wwwroot . '/grade/report/overview/index.php';
  $preferences_link = $CFG->wwwroot . '/user/preferences.php';
} else {
  $isloggedin = 'FALSE';
  $messages_link = '';
  $profile_link = '';
  $grades_link = '';
  $preferences_link = '';
}
if (function_exists('signup_is_enabled') && signup_is_enabled()) {
  $signup_is_enabled = true;
} else {
  $signup_is_enabled = false;
}
if (get_config('theme_edumy', 'library_list') == 0){
  $display_library_list = false;
} else {
  $display_library_list = true;
}
if (get_config('theme_edumy', 'logotype') == 1){
  $logotype = false;
} else {
  $logotype = true;
}
if (get_config('theme_edumy', 'logo_image') == 1){
  $logo_image = false;
} else {
  $logo_image = true;
}
if (!$logotype && !$logo_image){
  $logo = false;
} else {
  $logo = true;
}
if (get_config('theme_edumy', 'logotype_footer') == 1){
  $logotype_footer = false;
} else {
  $logotype_footer = true;
}
if (get_config('theme_edumy', 'logo_image_footer') == 1){
  $logo_image_footer = false;
} else {
  $logo_image_footer = true;
}
if (!$logotype_footer && !$logo_image_footer){
  $logo_footer = false;
} else {
  $logo_footer = true;
}
if(get_config('theme_edumy', 'custom_css')){
  $custom_css = '<style>'.get_config('theme_edumy', 'custom_css').'</style>';
} else {
  $custom_css = '';
}
if(get_config('theme_edumy', 'custom_css_dashboard')){
  $custom_css_dashboard = '<style>'.get_config('theme_edumy', 'custom_css_dashboard').'</style>';
} else {
  $custom_css_dashboard = '';
}
if(get_config('theme_edumy', 'custom_js')){
  $custom_js = '<script>'.get_config('theme_edumy', 'custom_js').'</script>';
} else {
  $custom_js = '';
}
if(get_config('theme_edumy', 'custom_js_dashboard')){
  $custom_js_dashboard = '<script>'.get_config('theme_edumy', 'custom_js_dashboard').'</script>';
} else {
  $custom_js_dashboard = '';
}
$footer_column_count = 0;
$footer_column_1 = false;
$footer_column_2 = false;
$footer_column_3 = false;
$footer_column_4 = false;
$footer_column_5 = false;
if(get_config('theme_edumy', 'footer_col_1_title') || get_config('theme_edumy', 'footer_col_1_body')){
  $footer_column_count++;
  $footer_column_1 = true;
}
if(get_config('theme_edumy', 'footer_col_2_title') || get_config('theme_edumy', 'footer_col_2_body')){
  $footer_column_count++;
  $footer_column_2 = true;
}
if(get_config('theme_edumy', 'footer_col_3_title') || get_config('theme_edumy', 'footer_col_3_body')){
  $footer_column_count++;
  $footer_column_3 = true;
}
if(get_config('theme_edumy', 'footer_col_4_title') || get_config('theme_edumy', 'footer_col_4_body')){
  $footer_column_count++;
  $footer_column_4 = true;
}
if(get_config('theme_edumy', 'footer_col_5_title') || get_config('theme_edumy', 'footer_col_5_body')){
  $footer_column_count++;
  $footer_column_5 = true;
}
if($footer_column_count == 4) {
  $footer_col_1_class = "col-sm-6 col-md-6 col-md-3 col-lg-3";
  $footer_col_2_class = "col-sm-6 col-md-6 col-md-3 col-lg-3";
  $footer_col_3_class = "col-sm-6 col-md-6 col-md-3 col-lg-3";
  $footer_col_4_class = "col-sm-6 col-md-6 col-md-3 col-lg-3";
  $footer_col_5_class = "";
} elseif($footer_column_count == 3) {
  $footer_col_1_class = "col-sm-12 col-md-4 col-md-4 col-lg-4";
  $footer_col_2_class = "col-sm-12 col-md-4 col-md-4 col-lg-4";
  $footer_col_3_class = "col-sm-12 col-md-4 col-md-4 col-lg-4";
  $footer_col_4_class = "";
  $footer_col_5_class = "";
} elseif($footer_column_count == 2) {
  $footer_col_1_class = "col-sm-6 col-md-6 col-md-6 col-lg-6";
  $footer_col_2_class = "col-sm-6 col-md-6 col-md-6 col-lg-6";
  $footer_col_3_class = "";
  $footer_col_4_class = "";
  $footer_col_5_class = "";
} elseif($footer_column_count == 1) {
  $footer_col_1_class = "col-sm-12 col-md-6 offset-md-6";
  $footer_col_2_class = "";
  $footer_col_3_class = "";
  $footer_col_4_class = "";
  $footer_col_5_class = "";
} else {
  $footer_col_1_class = "col-sm-6 col-md-4 col-md-3 col-lg-3";
  $footer_col_2_class = "col-sm-6 col-md-4 col-md-3 col-lg-2";
  $footer_col_3_class = "col-sm-6 col-md-4 col-md-3 col-lg-2";
  $footer_col_4_class = "col-sm-6 col-md-4 col-md-3 col-lg-2";
  $footer_col_5_class = "col-sm-6 col-md-4 col-md-3 col-lg-3";
}
if(!empty($USER->username)){$USER->username = $USER->username;}else{$USER->username = '';}
if(!empty($USER->firstname)){$USER->firstname = $USER->firstname;}else{$USER->firstname = '';}
if(!empty($USER->lastname)){$USER->lastname = $USER->lastname;}else{$USER->lastname = '';}
if(!empty($USER->email)){$USER->email = $USER->email;}else{$USER->email = '';}
if(!empty($USER->lang)){$USER->lang = $USER->lang;}else{$USER->lang = '';}
$templatecontext = [
    'sitename' => format_string($SITE->shortname, true, ['context' => context_course::instance(SITEID), "escape" => false]),
    'output' => $OUTPUT,
    'pageheading' => $pageheading,
    'sidepreblocks' => $blockshtml,
    'ccn_login' => $_ccnlogin,
    // 'ccn_registration' => $_ccnregistration,
    'ccn_globalsearch' => $_ccnglobalsearch,
    'ccn_globalsearch_navbar' => $_ccnglobalsearch_navbar,
    'ccn_librarylist' => $_ccnlibrarylist,
    'library_list_blocks' => $OUTPUT->blocks('library-list'),
    'has_library_list_blocks' => strpos($OUTPUT->blocks('library-list'), 'data-block=') !== false,
    'navbar_blocks' => $OUTPUT->blocks('navbar'),
    'has_navbar_blocks' => strpos($OUTPUT->blocks('navbar'), 'data-block=') !== false,
    'leftblocks' => $leftblocks,
    'hasblocks' => $hasblocks,
    'hasleftblocks' => $hasleftblocks,
    'hassideblocks' => $hassideblocks,
    'bodyattributes' => $bodyattributes,
    'headerlogo1' => $headerlogo1,
    'headerlogo2' => $headerlogo2,
    'headerlogo3' => $headerlogo3,
    'footerlogo1' => $footerlogo1,
    'heading_bg' => $heading_bg,
    'favicon' => $favicon,
    'regionmainsettingsmenu' => $regionmainsettingsmenu,
    'hasregionmainsettingsmenu' => !empty($regionmainsettingsmenu),
    'loginblocks' => $loginblocks,
    'hasloginblocks' => !empty($loginblocks),
    'searchblocks' => $searchblocks,
    'hassearchblocks' => !empty($searchblocks),
    'blocks_user_notifications' => $blocks_user_notifications,
    'blocks_user_messages' => $blocks_user_messages,
    'blocks_fullwidth_top' => $blocks_fullwidth_top,
    'blocks_fullwidth_bottom' => $blocks_fullwidth_bottom,
    'blocks_above_content' => $blocks_above_content,
    'has_blocks_above_content' => !empty($blocks_above_content),
    'blocks_below_content' => $blocks_below_content,
    'has_blocks_below_content' => !empty($blocks_below_content),
    'is_course' => $PAGE->bodyid == 'page-course-view-topics',
    'is_blog' => $PAGE->bodyid == 'page-blog-index',
    'is_frontpage' => $PAGE->bodyid == 'page-site-index',
    'courseid' => $courseid,
    'coursefullname' => $coursefullname,
    'courseshortname' => $courseshortname,
    'coursecategory' => $coursecategory,
    'coursesummary' => $coursesummary,
    'courseformat' => $courseformat,
    'coursecreated' => $coursecreated,
    'coursemodified' => $coursemodified,
    'coursestartdate' => $coursestartdate,
    'courseenddate' => $courseenddate,
    'numberofusers' => $numberofusers,
    'cocoon_facebook_url' => format_text(get_config('theme_edumy', 'cocoon_facebook_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_twitter_url' => format_text(get_config('theme_edumy', 'cocoon_twitter_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_instagram_url' => format_text(get_config('theme_edumy', 'cocoon_instagram_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_pinterest_url' => format_text(get_config('theme_edumy', 'cocoon_pinterest_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_dribbble_url' => format_text(get_config('theme_edumy', 'cocoon_dribbble_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_google_url' => format_text(get_config('theme_edumy', 'cocoon_google_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_youtube_url' => format_text(get_config('theme_edumy', 'cocoon_youtube_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_vk_url' => format_text(get_config('theme_edumy', 'cocoon_vk_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_500px_url' => format_text(get_config('theme_edumy', 'cocoon_500px_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_behance_url' => format_text(get_config('theme_edumy', 'cocoon_behance_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_digg_url' => format_text(get_config('theme_edumy', 'cocoon_digg_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_flickr_url' => format_text(get_config('theme_edumy', 'cocoon_flickr_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_foursquare_url' => format_text(get_config('theme_edumy', 'cocoon_foursquare_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_linkedin_url' => format_text(get_config('theme_edumy', 'cocoon_linkedin_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_medium_url' => format_text(get_config('theme_edumy', 'cocoon_medium_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_meetup_url' => format_text(get_config('theme_edumy', 'cocoon_meetup_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_snapchat_url' => format_text(get_config('theme_edumy', 'cocoon_snapchat_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_tumblr_url' => format_text(get_config('theme_edumy', 'cocoon_tumblr_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_vimeo_url' => format_text(get_config('theme_edumy', 'cocoon_vimeo_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_wechat_url' => format_text(get_config('theme_edumy', 'cocoon_wechat_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_whatsapp_url' => format_text(get_config('theme_edumy', 'cocoon_whatsapp_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_wordpress_url' => format_text(get_config('theme_edumy', 'cocoon_wordpress_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_weibo_url' => format_text(get_config('theme_edumy', 'cocoon_weibo_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_telegram_url' => format_text(get_config('theme_edumy', 'cocoon_telegram_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_moodle_url' => format_text(get_config('theme_edumy', 'cocoon_moodle_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_amazon_url' => format_text(get_config('theme_edumy', 'cocoon_amazon_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_slideshare_url' => format_text(get_config('theme_edumy', 'cocoon_slideshare_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_soundcloud_url' => format_text(get_config('theme_edumy', 'cocoon_soundcloud_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_leanpub_url' => format_text(get_config('theme_edumy', 'cocoon_leanpub_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_xing_url' => format_text(get_config('theme_edumy', 'cocoon_xing_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_bitcoin_url' => format_text(get_config('theme_edumy', 'cocoon_bitcoin_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_twitch_url' => format_text(get_config('theme_edumy', 'cocoon_twitch_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_github_url' => format_text(get_config('theme_edumy', 'cocoon_github_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_gitlab_url' => format_text(get_config('theme_edumy', 'cocoon_gitlab_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_forumbee_url' => format_text(get_config('theme_edumy', 'cocoon_forumbee_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_trello_url' => format_text(get_config('theme_edumy', 'cocoon_trello_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_weixin_url' => format_text(get_config('theme_edumy', 'cocoon_weixin_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_slack_url' => format_text(get_config('theme_edumy', 'cocoon_slack_url'), FORMAT_HTML, array('filter' => true)),
    'cocoon_copyright' => format_text(get_config('theme_edumy', 'cocoon_copyright'), FORMAT_HTML, array('filter' => true)),
    'footer_col_1_title' => format_text(get_config('theme_edumy', 'footer_col_1_title'), FORMAT_HTML, array('filter' => true)),
    'footer_col_1_body' => format_text(get_config('theme_edumy', 'footer_col_1_body'), FORMAT_HTML, array('filter' => true)),
    'footer_col_2_title' => format_text(get_config('theme_edumy', 'footer_col_2_title'), FORMAT_HTML, array('filter' => true)),
    'footer_col_2_body' => format_text(get_config('theme_edumy', 'footer_col_2_body'), FORMAT_HTML, array('filter' => true)),
    'footer_col_3_title' => format_text(get_config('theme_edumy', 'footer_col_3_title'), FORMAT_HTML, array('filter' => true)),
    'footer_col_3_body' => format_text(get_config('theme_edumy', 'footer_col_3_body'), FORMAT_HTML, array('filter' => true)),
    'footer_col_4_title' => format_text(get_config('theme_edumy', 'footer_col_4_title'), FORMAT_HTML, array('filter' => true)),
    'footer_col_4_body' => format_text(get_config('theme_edumy', 'footer_col_4_body'), FORMAT_HTML, array('filter' => true)),
    'footer_col_5_title' => format_text(get_config('theme_edumy', 'footer_col_5_title'), FORMAT_HTML, array('filter' => true)),
    'footer_col_5_body' => format_text(get_config('theme_edumy', 'footer_col_5_body'), FORMAT_HTML, array('filter' => true, 'noclean' => true)),
    'footer_menu' => format_text(get_config('theme_edumy', 'footer_menu'), FORMAT_HTML, array('filter' => true)),
    'footer_column_1' => $footer_column_1,
    'footer_column_2' => $footer_column_2,
    'footer_column_3' => $footer_column_3,
    'footer_column_4' => $footer_column_4,
    'footer_column_5' => $footer_column_5,
    'footer_col_1_class' => $footer_col_1_class,
    'footer_col_2_class' => $footer_col_2_class,
    'footer_col_3_class' => $footer_col_3_class,
    'footer_col_4_class' => $footer_col_4_class,
    'footer_col_5_class' => $footer_col_5_class,
    'cta_text' => format_text(get_config('theme_edumy', 'cta_text'), FORMAT_HTML, array('filter' => true)),
    'cta_link' => format_text(get_config('theme_edumy', 'cta_link'), FORMAT_HTML, array('filter' => true)),
    'email_address' => format_text(get_config('theme_edumy', 'email_address'), FORMAT_HTML, array('filter' => true)),
    'phone' => format_text(get_config('theme_edumy', 'phone'), FORMAT_HTML, array('filter' => true)),
    'custom_css' => $custom_css,
    'custom_css_dashboard' => $custom_css_dashboard,
    'custom_js' => $custom_js,
    'custom_js_dashboard' => $custom_js_dashboard,
    'display_library_list' => $display_library_list,
    'logotype' => $logotype,
    'logo_image' => $logo_image,
    'logo' => $logo,
    'logotype_footer' => $logotype_footer,
    'logo_image_footer' => $logo_image_footer,
    'logo_footer' => $logo_footer,
    'user_profile_picture' => new moodle_url('/user/pix.php/'.$USER->id.'/f1.jpg'),
    'user_username' => $USER->username,
    'user_firstname' => $USER->firstname,
    'user_lastname' => $USER->lastname,
    'user_email' => $USER->email,
    'user_language' => $USER->lang,
    'user_id' => $USER->id,
    'isloggedin' => $isloggedin == 'TRUE',
    'notloggedin' => $isloggedin == 'FALSE',
    'signup_is_enabled' => $signup_is_enabled == true,
    'signup_is_disabled' => $signup_is_enabled == false,
    'header_1' => $headertype == 1,
    'header_2' => $headertype == 2,
    'header_3' => $headertype == 3,
    'header_4' => $headertype == 4,
    'header_5' => $headertype == 5,
    'header_6' => $headertype == 6,
    'header_7' => $headertype == 7,
    'header_8' => $headertype == 8,
    'footer_1' => $footertype == 1,
    'footer_2' => $footertype == 2,
    'footer_3' => $footertype == 3,
    'footer_4' => $footertype == 4,
    'breadcrumb_default' => $breadcrumb_style == 0,
    'breadcrumb_m' => $breadcrumb_style == 1,
    'breadcrumb_s' => $breadcrumb_style == 2,
    'breadcrumb_xs' => $breadcrumb_style == 3,
    'breadcrumb_hidden' => $breadcrumb_style == 4,
    'preloader_load' => $preloader_duration == 0,
    'preloader_ready' => $preloader_duration == 1,
    'preloader_5' => $preloader_duration == 2,
    'preloader_4' => $preloader_duration == 3,
    'preloader_3' => $preloader_duration == 4,
    'preloader_2' => $preloader_duration == 5,
    'preloader_disable' => $preloader_duration == 6,
    'headertype_frontpage_only' => $headertype_settings == 0,
    'headertype_all_pages' => $headertype_settings == 1,
    'header_search_icon' => $header_search == 0,
    'header_search_bar' => $header_search == 1,
    'header_login_popup' => $header_login == 0,
    'header_login_link' => $header_login == 1,
    'back_to_top' => $back_to_top == 0,
    'dashboard_sticky_header' => $dashboard_sticky_header == 0,
    'logo_styles' => $logo_styles,
    'logo_styles_footer' => $logo_styles_footer,
    'gmaps_key' => get_config('theme_edumy', 'gmaps_key'),
    'messages_link' => $messages_link,
    'profile_link' => $profile_link,
    'preferences_link' => $preferences_link,
    'grades_link' => $grades_link,
    'display_course_content' => $display_course_content == 1,
    'social_target_href' => $social_target_href,
];
$PAGE->requires->jquery();
$nav = $PAGE->flatnav;
$templatecontext['flatnavigation'] = $nav;
$templatecontext['firstcollectionlabel'] = $nav->get_collectionlabel();
