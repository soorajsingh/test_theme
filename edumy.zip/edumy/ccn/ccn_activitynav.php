<?php
/*
@ccnRef: @template navigation
*/

defined('MOODLE_INTERNAL') || die();

// print_object($this->page->navigation);
