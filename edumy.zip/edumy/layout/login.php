<?php
defined('MOODLE_INTERNAL') || die();
include($CFG->dirroot . '/theme/edumy/ccn/ccn_themehandler.php');
echo $OUTPUT->render_from_template('theme_boost/login', $templatecontext);
